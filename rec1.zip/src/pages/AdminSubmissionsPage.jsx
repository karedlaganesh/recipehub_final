import { useApp } from '../context/AppContext.jsx';

export default function AdminSubmissionsPage() {
  const { submissions, reviewSubmission, notify } = useApp();
  return <section className="container admin-section"><div className="section-page-header"><div><span className="section-tag">Community Submissions</span><h1 className="section-title">User Submissions</h1><p className="section-subtitle">Approve recipes to publish them to the catalog.</p></div></div>
    <div className="table-responsive-wrapper"><table className="data-table"><thead><tr><th>Recipe Name</th><th>Submitted By</th><th>Date</th><th>Status</th><th>Actions</th></tr></thead><tbody>{submissions.map((submission) => <tr key={submission.id}><td>{submission.name}</td><td>{submission.submittedBy}</td><td>{submission.submittedAt}</td><td>{submission.status}</td><td>{submission.status === 'pending' && <><button className="btn btn-primary-green btn-sm" onClick={() => { reviewSubmission(submission.id, 'approved'); notify('Submission approved and published.'); }}>Approve</button> <button className="btn btn-outline-danger btn-sm" onClick={() => reviewSubmission(submission.id, 'rejected')}>Reject</button></>}</td></tr>)}</tbody></table></div>
    {!submissions.length && <div className="empty-state-box">No recipe submissions yet.</div>}
  </section>;
}

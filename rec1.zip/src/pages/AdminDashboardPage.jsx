import { Link } from 'react-router-dom';
import { useApp } from '../context/AppContext.jsx';

export default function AdminDashboardPage() {
  const { session, recipes, users, submissions, ratings } = useApp();
  const ratingCount = Object.values(ratings).reduce((sum, recipeRatings) => sum + Object.keys(recipeRatings).length, 0);
  const pending = submissions.filter((submission) => submission.status === 'pending').length;
  return (
    <section className="container admin-section dashboard-section">
      <div className="dashboard-welcome-banner"><div className="welcome-text-col"><span className="welcome-tag">Administration</span><h1 className="welcome-heading">Welcome, {session.account.name}!</h1><p className="welcome-subtext">Manage the Recipe Hub catalog and community.</p></div><div className="welcome-actions-col"><Link className="btn btn-primary-green" to="/admin/recipes/new">+ Add Recipe</Link></div></div>
      <div className="dashboard-stats-grid"><Stat label="Recipes" value={recipes.length} icon="🍽️" /><Stat label="Users" value={users.length} icon="👥" /><Stat label="Ratings" value={ratingCount} icon="⭐" /><Stat label="Pending Submissions" value={pending} icon="📝" /></div>
      <div className="admin-dash-grid">
        <article className="admin-panel-card"><div className="admin-panel-header"><h2>Manage Catalog</h2><Link to="/admin/recipes">View Recipes →</Link></div><p>Add, inspect, and remove published recipes.</p></article>
        <article className="admin-panel-card"><div className="admin-panel-header"><h2>Community Submissions</h2><Link to="/admin/submissions">Review Submissions →</Link></div><p>{pending} recipes are awaiting review.</p></article>
        <article className="admin-panel-card"><div className="admin-panel-header"><h2>Ratings Overview</h2><Link to="/admin/ratings">View Ratings →</Link></div><p>Explore community recipe ratings and feedback.</p></article>
      </div>
    </section>
  );
}

function Stat({ label, value, icon }) {
  return <article className="stat-card"><div className="stat-card-icon-wrap">{icon}</div><div className="stat-card-content"><span className="stat-card-title">{label}</span><span className="stat-card-value">{value}</span></div></article>;
}

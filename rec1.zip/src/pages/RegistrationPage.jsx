import { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { useApp } from '../context/AppContext.jsx';

function Field({ label, id, type = 'text', value, onChange, error, ...props }) {
  return (
    <div className="form-group">
      <label htmlFor={id}>{label} <span className="required">*</span></label>
      <input id={id} type={type} className="form-control" value={value} onChange={onChange} required {...props} />
      {error && <span className="field-error">{error}</span>}
    </div>
  );
}

export default function RegistrationPage() {
  const [params] = useSearchParams();
  const [role, setRole] = useState(params.get('role') === 'admin' ? 'admin' : 'user');
  const [form, setForm] = useState({ name: '', email: '', username: '', password: '', confirm: '', adminKey: '' });
  const [errors, setErrors] = useState({});
  const [message, setMessage] = useState('');
  const { register } = useApp();
  const navigate = useNavigate();
  const admin = role === 'admin';

  function change(field) {
    return (event) => setForm((current) => ({ ...current, [field]: event.target.value }));
  }

  function submit(event) {
    event.preventDefault();
    const nextErrors = {};
    if (!form.name.trim()) nextErrors.name = 'Please enter your full name.';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim())) nextErrors.email = 'Please enter a valid email address.';
    if (form.username.trim().length < 3) nextErrors.username = 'Username must be at least 3 characters.';
    if (form.password.length < 6) nextErrors.password = 'Password must be at least 6 characters.';
    if (form.password !== form.confirm) nextErrors.confirm = 'Passwords do not match.';
    if (admin && form.adminKey !== 'ADMIN2026') nextErrors.adminKey = 'Invalid admin passcode.';
    setErrors(nextErrors);
    setMessage('');
    if (Object.keys(nextErrors).length) return;

    const result = register(role, {
      name: form.name.trim(),
      email: form.email.trim(),
      username: form.username.trim(),
      password: form.password,
    });
    if (!result.ok) {
      setMessage(result.error);
      return;
    }
    setMessage(`${admin ? 'Administrator' : 'User'} account created successfully.`);
    window.setTimeout(() => navigate(admin ? '/admin/login' : '/login', { replace: true }), 1200);
  }

  return (
    <section className="auth-page-main">
      <div className="container auth-container">
        <div className="auth-card">
          <div className="auth-header text-center">
            <div className="auth-logo-badge"><span aria-hidden="true">🍳</span></div>
            <h1 className="auth-title">{admin ? 'Create Administrator Account' : 'Create Your Recipe Hub Account'}</h1>
            <p className="auth-subtitle">Join Recipe Hub to discover recipes, save favorites, and share your cooking ideas.</p>
          </div>
          <div className="auth-role-tabs" role="tablist" aria-label="Account type selector">
            <button type="button" className={`role-tab${!admin ? ' active' : ''}`} role="tab" aria-selected={!admin} onClick={() => { setRole('user'); setMessage(''); }}>👨‍🍳 User Account</button>
            <button type="button" className={`role-tab${admin ? ' active' : ''}`} role="tab" aria-selected={admin} onClick={() => { setRole('admin'); setMessage(''); }}>🛡️ Admin Account</button>
          </div>
          {message && <div role="status" className={`alert-box ${message.includes('successfully') ? 'alert-success' : 'alert-danger'}`}>{message}</div>}
          <form onSubmit={submit} noValidate>
            <Field label="Full Name" id="reg-fullname" value={form.name} onChange={change('name')} error={errors.name} autoComplete="name" />
            <Field label="Email" id="reg-email" type="email" value={form.email} onChange={change('email')} error={errors.email} autoComplete="email" />
            <Field label="Username" id="reg-username" value={form.username} onChange={change('username')} error={errors.username} autoComplete="username" />
            <Field label="Password" id="reg-password" type="password" value={form.password} onChange={change('password')} error={errors.password} autoComplete="new-password" />
            <Field label="Confirm Password" id="reg-confirm" type="password" value={form.confirm} onChange={change('confirm')} error={errors.confirm} autoComplete="new-password" />
            {admin && (
              <div className="form-group">
                <label htmlFor="reg-adminkey">Admin Authorization Passcode <span className="required">*</span></label>
                <input id="reg-adminkey" className="form-control" type="password" value={form.adminKey} onChange={change('adminKey')} required />
                <small className="form-hint">For testing, default passcode is <code>ADMIN2026</code>.</small>
                {errors.adminKey && <span className="field-error">{errors.adminKey}</span>}
              </div>
            )}
            <button type="submit" className={`btn ${admin ? 'btn-primary-green' : 'btn-primary-orange'} btn-block btn-lg`}>Create {admin ? 'Admin ' : ''}Account</button>
          </form>
          <div className="auth-footer text-center">
            <p>Already have an account? <Link to={admin ? '/admin/login' : '/login'} className="text-orange font-bold">Login</Link></p>
            <p><Link to="/">← Return to Home Page</Link></p>
          </div>
        </div>
      </div>
    </section>
  );
}

import { useEffect, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext.jsx';

export default function AuthForm({ role }) {
  const { login, notify, session } = useApp();
  const location = useLocation();
  const navigate = useNavigate();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const isAdmin = role === 'admin';
  const target = location.state?.from?.pathname || (isAdmin ? '/admin' : '/user/dashboard');

  useEffect(() => {
    if (session?.role === role) navigate(target, { replace: true });
  }, [session, role, target, navigate]);

  function submit(event) {
    event.preventDefault();
    if (!login(role, username, password)) {
      setError('Incorrect username or password.');
      return;
    }
    notify(`Welcome back, ${username.trim()}!`);
    navigate(target, { replace: true });
  }

  return (
    <section className="auth-page-body auth-page-main">
      <div className="container auth-container">
        <div className="auth-card">
          <div className="auth-header text-center">
            <div className="auth-logo-badge"><span aria-hidden="true">🍳</span></div>
            <h1 className="auth-title">{isAdmin ? 'Admin Login' : 'Welcome Back'}</h1>
            <p className="auth-subtitle">{isAdmin ? 'Sign in to manage recipes and community submissions.' : 'Login to save recipes, rate dishes, and manage your collections.'}</p>
          </div>
          {error && <div role="alert" className="alert-box alert-danger"><span className="alert-icon">⚠️</span><p>{error}</p></div>}
          <form onSubmit={submit}>
            <div className="form-group">
              <label htmlFor={`${role}-username`}>Username</label>
              <input id={`${role}-username`} className="form-control" autoComplete="username" value={username} onChange={(event) => setUsername(event.target.value)} required />
            </div>
            <div className="form-group">
              <label htmlFor={`${role}-password`}>Password</label>
              <input id={`${role}-password`} className="form-control" type="password" autoComplete="current-password" value={password} onChange={(event) => setPassword(event.target.value)} required />
            </div>
            <button
              type="button"
              className="btn btn-outline-dark btn-block demo-autofill-btn"
              onClick={() => {
                setUsername(isAdmin ? 'admin' : 'foodie');
                setPassword(isAdmin ? 'admin123' : 'password123');
                setError('');
              }}
            >
              Autofill demo credentials
            </button>
            <button type="submit" className={`btn ${isAdmin ? 'btn-primary-green' : 'btn-primary-orange'} btn-block btn-lg`}>Login</button>
          </form>
          <div className="auth-footer text-center">
            <p>Demo: <code>{isAdmin ? 'admin / admin123' : 'foodie / password123'}</code></p>
            {!isAdmin && <p>New to Recipe Hub? <Link to="/register" className="text-orange font-bold">Create an account</Link></p>}
            {isAdmin && <p><Link to="/register?role=admin" className="text-green font-bold">Register an administrator account</Link></p>}
            <p><Link to="/" className="text-muted">Return to Home</Link></p>
          </div>
        </div>
      </div>
    </section>
  );
}

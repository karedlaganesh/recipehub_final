import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { useApp } from '../context/AppContext.jsx';

export default function RecipeDetailPage() {
  const { recipeId } = useParams();
  const { recipes, ratings, submitRating, notify, session, savedRecipes, toggleSaved, collections, updateCollection } = useApp();
  const navigate = useNavigate();
  const recipe = recipes.find((item) => item.id === recipeId);
  const userRating = session?.role === 'user' ? ratings[recipeId]?.[session.account.id] || 0 : 0;
  const [servings, setServings] = useState(recipe?.servings || 1);
  const [score, setScore] = useState(userRating);
  const [collectionId, setCollectionId] = useState('');
  const userCollections = session?.role === 'user' ? collections[session.account.id] || [] : [];
  const selectedCollection = userCollections.find((collection) => collection.id === collectionId);
  const isInCollection = selectedCollection?.recipeIds?.includes(recipeId) || false;
  const isSaved = session?.role === 'user' && (savedRecipes[session.account.id] || []).includes(recipeId);

  useEffect(() => {
    setScore(userRating);
  }, [recipeId, userRating]);

  if (!recipe) {
    return <section className="container empty-state-box"><h1>Recipe not found</h1><Link className="btn btn-primary-orange" to="/recipes">Browse Recipes</Link></section>;
  }

  const servingMultiplier = servings / (recipe.servings || 1);

  function scaleIngredient(ingredient) {
    const match = ingredient.match(/^(\d+(?:\.\d+)?|\d+\/\d+)(\s*)(.*)$/);
    if (!match) return ingredient;
    const amount = match[1].includes('/')
      ? Number(match[1].split('/')[0]) / Number(match[1].split('/')[1])
      : Number(match[1]);
    const scaled = amount * servingMultiplier;
    const formatted = Number.isInteger(scaled) ? String(scaled) : Number(scaled.toFixed(2)).toString();
    return `${formatted}${match[2]}${match[3]}`;
  }

  async function share() {
    const url = window.location.href;
    try {
      if (navigator.share) await navigator.share({ title: recipe.name, text: recipe.description, url });
      else {
        await navigator.clipboard.writeText(url);
        notify('Recipe link copied to clipboard.');
      }
    } catch (error) {
      if (error.name !== 'AbortError') {
        console.error('Unable to share recipe.', error);
        notify('Sharing is not available in this browser.');
      }
    }
  }

  function rate() {
    if (session?.role !== 'user') {
      notify('Sign in with a user account to rate recipes.');
      return;
    }
    if (!score) {
      notify('Choose a star rating first.');
      return;
    }
    submitRating(recipe.id, score);
    notify('Thanks for rating this recipe!');
  }

  return (
    <section className="container recipe-detail-page">
      <button className="btn btn-outline-dark btn-sm" onClick={() => navigate(-1)}>← Back</button>
      <div className="recipe-detail-card">
        <img className="recipe-detail-image" src={recipe.image} alt={recipe.name} />
        <div className="recipe-detail-content">
          <div className="recipe-card-badges"><span className="recipe-tag tag-cuisine">{recipe.cuisine}</span><span className="recipe-tag tag-diet">{recipe.dietaryPreference}</span><span className="recipe-tag tag-meal">{recipe.mealType}</span></div>
          <span className="section-tag">Recipe Hub Kitchen</span>
          <h1 className="section-title">{recipe.name}</h1>
          <p className="recipe-detail-hero-desc">{recipe.description}</p>
          <div className="recipe-meta-row">
            {recipe.prepTime != null && recipe.prepTime !== '' && Number.isFinite(Number(recipe.prepTime)) && <span>⏱️ Prep {recipe.prepTime} min</span>}
            {recipe.cookTime != null && recipe.cookTime !== '' && Number.isFinite(Number(recipe.cookTime)) && <span>🍳 Cook {recipe.cookTime} min</span>}
            <span>★ {Number(recipe.rating || 0).toFixed(1)} ({recipe.ratingsCount || 0})</span>
            <span>{recipe.difficulty}</span>
          </div>
          <label className="serving-control" htmlFor="serving-count">Servings <input id="serving-count" type="number" min="1" value={servings} onChange={(event) => setServings(Math.max(1, Number(event.target.value)))} /></label>
          <h2>Ingredients</h2>
          <ul className="recipe-ingredients-list">{(recipe.ingredients || []).map((ingredient, index) => <li key={`${ingredient}-${index}`}><label><input type="checkbox" /> {scaleIngredient(ingredient)}</label></li>)}</ul>
          <h2>Cooking Instructions</h2>
          <ol className="recipe-instructions-list">{(recipe.instructions || []).map((instruction, index) => <li key={`${instruction}-${index}`}>{instruction}</li>)}</ol>
          <div className="recipe-detail-actions"><button className={`btn ${isSaved ? 'btn-outline-orange' : 'btn-primary-orange'}`} onClick={() => { toggleSaved(recipe.id); notify(isSaved ? 'Removed from saved recipes.' : 'Recipe saved!'); }}>{isSaved ? '♥ Saved Recipe' : '♡ Save Recipe'}</button><button className="btn btn-outline-dark" onClick={share}>Share Recipe</button></div>
          {userCollections.length > 0 && <div className="collection-add-row"><label htmlFor="recipe-collection">Add to collection</label><select className="form-select" id="recipe-collection" value={collectionId} onChange={(event) => setCollectionId(event.target.value)}><option value="">Choose collection</option>{userCollections.map((collection) => <option value={collection.id} key={collection.id}>{collection.name}</option>)}</select><button className="btn btn-outline-orange btn-sm" disabled={!collectionId} onClick={() => { updateCollection(collectionId, recipe.id, isInCollection); notify(isInCollection ? 'Recipe removed from collection.' : 'Recipe added to collection.'); }}>{isInCollection ? 'Remove' : 'Add'}</button></div>}
          <div className="recipe-rating-form">
            <h3>How was your cooking experience?</h3>
            {session?.role === 'user' ? (
              <>
                <div className="interactive-star-rating" role="radiogroup" aria-label="Rate recipe">
                  {[1, 2, 3, 4, 5].map((value) => (
                    <button
                      key={value}
                      type="button"
                      role="radio"
                      aria-checked={score === value}
                      className={`star-pick${score >= value ? ' selected' : ''}`}
                      aria-label={`${value} stars`}
                      onClick={() => setScore(value)}
                    >★</button>
                  ))}
                </div>
                <button className="btn btn-primary-orange btn-sm" disabled={!score} onClick={rate}>
                  {userRating ? 'Update Rating' : 'Submit Rating'}
                </button>
                {userRating > 0 && <p className="text-sm text-muted">Your rating: {userRating} / 5</p>}
              </>
            ) : <p className="text-muted">Sign in with a user account to rate this recipe.</p>}
          </div>
        </div>
      </div>
    </section>
  );
}

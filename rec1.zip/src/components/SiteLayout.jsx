import { useState } from 'react';
import { Link, NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext.jsx';

function Brand({ footer = false }) {
  return (
    <Link to="/" className={`brand-logo${footer ? ' footer-logo' : ''}`} aria-label="Recipe Hub Home">
      <span className="logo-icon-wrap" aria-hidden="true">
        <svg className="chef-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M6 13.87A4 4 0 0 1 7.41 6a5.11 5.11 0 0 1 1.05-1.54 5 5 0 0 1 7.08 0A5.11 5.11 0 0 1 16.59 6 4 4 0 0 1 18 13.87V21H6Z" />
          <line x1="6" y1="17" x2="18" y2="17" />
        </svg>
      </span>
      <span className="brand-text">
        <span className="brand-name">Recipe Hub</span>
        <span className="brand-tagline">Discover. Cook. Share.</span>
      </span>
    </Link>
  );
}

export function Footer() {
  return (
    <footer className="app-footer">
      <div className="container footer-container">
        <div>
          <Brand footer />
          <p className="footer-desc">Your modern kitchen companion. Bringing authentic, delicious, and easy-to-follow recipes to home chefs everywhere.</p>
        </div>
        <div className="footer-links-col">
          <h4 className="footer-title">Quick Links</h4>
          <ul>
            <li><Link to="/">Home</Link></li>
            <li><a href="/#about">About</a></li>
            <li><a href="/#features">Features</a></li>
            <li><Link to="/recipes">Recipes</Link></li>
            <li><a href="/#contact">Contact</a></li>
          </ul>
        </div>
        <div className="footer-links-col">
          <h4 className="footer-title">Modules</h4>
          <ul>
            <li><Link to="/login">User Login</Link></li>
            <li><Link to="/register">User Registration</Link></li>
            <li><Link to="/admin/login">Admin Login</Link></li>
            <li><Link to="/register?role=admin">Admin Registration</Link></li>
          </ul>
        </div>
        <div className="footer-links-col">
          <h4 className="footer-title">Campus &amp; Location</h4>
          <p className="text-sm"><strong>KL University</strong></p>
          <p className="text-sm text-muted">Vaddeswaram, Andhra Pradesh, India</p>
          <div className="demo-pill-footer"><span className="text-xs">Quick Demo: <code>foodie / password123</code></span></div>
        </div>
      </div>
      <div className="footer-bottom">
        <div className="container footer-bottom-inner">
          <p>&copy; Recipe Hub</p>
          <a className="footer-back-top" href="#app-header">Back to Top &uarr;</a>
        </div>
      </div>
    </footer>
  );
}

export default function SiteLayout() {
  const { session, logout, savedRecipes, submissions, toast } = useApp();
  const [menuOpen, setMenuOpen] = useState(false);
  const navigate = useNavigate();
  const savedCount = session?.role === 'user' ? (savedRecipes[session.account.id] || []).length : 0;
  const pendingCount = submissions.filter((submission) => submission.status === 'pending').length;
  const closeMenu = () => setMenuOpen(false);

  const publicLinks = [
    ['Home', '/'],
    ['About', '/#about'],
    ['Features', '/#features'],
    ['Recipes', '/recipes'],
    ['Contact', '/#contact'],
  ];

  return (
    <>
      {toast && <div className="toast-container" aria-live="polite"><div className="toast toast-info"><span>ℹ️</span><span>{toast}</span></div></div>}
      <header className="app-header" id="app-header">
        <div className="header-inner container">
          <Brand />
          <button
            className={`mobile-menu-toggle${menuOpen ? ' open' : ''}`}
            aria-label="Toggle navigation menu"
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen((open) => !open)}
          >
            <span className="bar" /><span className="bar" /><span className="bar" />
          </button>
          <nav className={`nav-container${menuOpen ? ' open' : ''}`}>
            {!session && (
              <ul className="nav-list">
                {publicLinks.map(([label, to]) => (
                  <li key={label}><NavLink onClick={closeMenu} to={to} className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`}>{label}</NavLink></li>
                ))}
                <li className="nav-btn-item"><Link onClick={closeMenu} to="/login" className="btn btn-outline-orange nav-btn">User</Link></li>
                <li className="nav-btn-item"><Link onClick={closeMenu} to="/admin/login" className="btn btn-primary-green nav-btn">Admin</Link></li>
              </ul>
            )}
            {session?.role === 'user' && (
              <ul className="nav-list">
                {publicLinks.map(([label, to]) => (
                  <li key={label}><NavLink onClick={closeMenu} to={to} className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`}>{label}</NavLink></li>
                ))}
                <li><NavLink onClick={closeMenu} to="/user/dashboard" className="nav-link">Dashboard</NavLink></li>
                <li><NavLink onClick={closeMenu} to="/user/saved" className="nav-link">Saved Recipes <span className="badge badge-orange">{savedCount}</span></NavLink></li>
                <li><NavLink onClick={closeMenu} to="/user/collections" className="nav-link">My Collections</NavLink></li>
                <li><NavLink onClick={closeMenu} to="/user/submit" className="nav-link">Submit Recipe</NavLink></li>
                <li className="admin-profile-badge"><span className="user-avatar-circle">{session.account.name?.[0]?.toUpperCase() || 'U'}</span><span className="user-name-display">{session.account.name}</span></li>
                <li><button className="btn btn-outline-danger btn-sm" onClick={() => { logout(); navigate('/'); }}>Logout</button></li>
              </ul>
            )}
            {session?.role === 'admin' && (
              <ul className="nav-list">
                {publicLinks.map(([label, to]) => (
                  <li key={label}><NavLink onClick={closeMenu} to={to} className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`}>{label}</NavLink></li>
                ))}
                <li><NavLink end onClick={closeMenu} to="/admin" className="nav-link">Dashboard</NavLink></li>
                <li><NavLink onClick={closeMenu} to="/admin/recipes" className="nav-link">Manage Recipes</NavLink></li>
                <li><NavLink onClick={closeMenu} to="/admin/recipes/new" className="nav-link">Add Recipe</NavLink></li>
                <li><NavLink onClick={closeMenu} to="/admin/submissions" className="nav-link">Submissions <span className="badge badge-warning">{pendingCount}</span></NavLink></li>
                <li><NavLink onClick={closeMenu} to="/admin/ratings" className="nav-link">Ratings</NavLink></li>
                <li className="admin-profile-badge"><span className="admin-avatar-circle">{session.account.name?.[0]?.toUpperCase() || 'A'}</span><span className="admin-name-display">{session.account.name}</span></li>
                <li><button className="btn btn-outline-danger btn-sm" onClick={() => { logout(); navigate('/'); }}>Logout</button></li>
              </ul>
            )}
          </nav>
        </div>
      </header>
      <main className="main-content"><Outlet /></main>
      <Footer />
    </>
  );
}
